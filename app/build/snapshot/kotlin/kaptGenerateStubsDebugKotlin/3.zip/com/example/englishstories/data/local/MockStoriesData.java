package com.example.englishstories.data.local;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u00c6\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002R\u0017\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u0017\u0010\b\u001a\b\u0012\u0004\u0012\u00020\t0\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u0007\u00a8\u0006\u000b"}, d2 = {"Lcom/example/englishstories/data/local/MockStoriesData;", "", "()V", "mockCategories", "", "Lcom/example/englishstories/model/Category;", "getMockCategories", "()Ljava/util/List;", "mockStories", "Lcom/example/englishstories/model/Story;", "getMockStories", "app_debug"})
public final class MockStoriesData {
    @org.jetbrains.annotations.NotNull
    private static final java.util.List<com.example.englishstories.model.Category> mockCategories = null;
    @org.jetbrains.annotations.NotNull
    private static final java.util.List<com.example.englishstories.model.Story> mockStories = null;
    @org.jetbrains.annotations.NotNull
    public static final com.example.englishstories.data.local.MockStoriesData INSTANCE = null;
    
    private MockStoriesData() {
        super();
    }
    
    @org.jetbrains.annotations.NotNull
    public final java.util.List<com.example.englishstories.model.Category> getMockCategories() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull
    public final java.util.List<com.example.englishstories.model.Story> getMockStories() {
        return null;
    }
}